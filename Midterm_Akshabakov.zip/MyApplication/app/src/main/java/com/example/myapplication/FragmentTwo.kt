package com.example.myapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentFirst.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentTwo : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    private val items = arrayListOf(
        "\t\t\tInception\nA mind-bending thriller about dreams within dreams.",
        "\t\t\tThe Dark Knight\nA gritty take on the Batman saga with Heath Ledger's iconic Joker.",
        "\t\t\tInterstellar\nA journey through space and time in search of a new home for humanity.",
        "\t\t\tThe Matrix\nA hacker discovers the true nature of reality in a dystopian future.",
        "\t\t\tPulp Fiction\nA series of interconnected stories in the world of crime in Los Angeles.",
        "\t\t\tFight Club\nAn underground fight club becomes a form of male bonding and rebellion.",
        "\t\t\tForrest Gump\nThe extraordinary life story of a man with a kind heart and a low IQ.",
        "\t\t\tThe Shawshank Redemption\nA tale of hope and friendship set in a prison.",
        "\t\t\tThe Godfather\nThe saga of an Italian-American crime family in the 1940s.",
        "\t\t\tGladiator\nA betrayed Roman general seeks revenge in the arena.",
        "\t\t\tThe Lord of the Rings: The Fellowship of the Ring\nA quest to destroy a powerful ring and save Middle-earth.",
        "\t\t\tSchindler's List\nThe true story of Oskar Schindler and his efforts to save Jews during the Holocaust.",
        "\t\t\tThe Silence of the Lambs\nA young FBI trainee seeks the help of a notorious serial killer.",
        "\t\t\tAvatar\nA visually stunning film about a human's journey on an alien world.",
        "\t\t\tTitanic\nA romantic tale set against the backdrop of the ill-fated ship's maiden voyage.",
        "\t\t\tJurassic Park\nA theme park filled with cloned dinosaurs goes horribly wrong.",
        "\t\t\tThe Avengers\nA team of superheroes comes together to save the world from a powerful threat.",
        "\t\t\tThe Departed\nAn undercover cop and a mole in the police try to identify each other.",
        "\t\t\tSaving Private Ryan\nA harrowing tale of soldiers during World War II.",
        "\t\t\tThe Social Network\nThe story behind the creation of Facebook and its impact."
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

//        val adapter = ArrayAdapter(this, R.id.listView1, items)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_two, container, false)

        val listView = view.findViewById<ListView>(R.id.listView2)

        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        return view
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment FragmentFirst.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            FragmentFirst().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}