package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.google.android.material.floatingactionbutton.FloatingActionButton

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class FragmentFirst : Fragment() {

    private var param1: String? = null
    private var param2: String? = null

    private val items = arrayListOf(
        "Inception", "The Dark Knight", "Interstellar", "The Matrix",
        "Pulp Fiction", "Fight Club", "Forrest Gump", "The Shawshank Redemption",
        "The Godfather", "Gladiator", "The Lord of the Rings: The Fellowship of the Ring",
        "Schindler's List", "The Silence of the Lambs", "Avatar", "Titanic",
        "Jurassic Park", "The Avengers", "The Departed", "Saving Private Ryan", "The Social Network"
    )

    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_first, container, false)

        val listView = view.findViewById<ListView>(R.id.listView1)
        adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, items)
        listView.adapter = adapter

        val fabAdd = view.findViewById<FloatingActionButton>(R.id.fab_add)
        fabAdd.setOnClickListener {
            showAddMovieDialog()
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            removeItem(position)
        }

        return view
    }

    private fun showAddMovieDialog() {
        val editText = EditText(requireContext())

        AlertDialog.Builder(requireContext())
            .setTitle("Add Movie")
            .setMessage("Enter the name of the movie:")
            .setView(editText) // Set the EditText as the dialog's view
            .setPositiveButton("Add") { dialog, _ ->
                val movieName = editText.text.toString()
                if (movieName.isNotBlank()) {
                    addItem(movieName)
                } else {
                    Toast.makeText(requireContext(), "Movie name cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addItem(movieName: String) {
        items.add(movieName)
        adapter.notifyDataSetChanged()
        Toast.makeText(requireContext(), "$movieName added", Toast.LENGTH_SHORT).show()
        Log.d("FragmentFirst", "Item added: $movieName")
    }

    private fun removeItem(position: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Remove Item")
            .setMessage("Do you want to remove ${items[position]}?")
            .setPositiveButton("Yes") { _, _ ->
                val removedItem = items.removeAt(position)
                adapter.notifyDataSetChanged()
                Toast.makeText(requireContext(), "$removedItem removed", Toast.LENGTH_SHORT).show()
                Log.d("FragmentFirst", "Item removed: $removedItem")
            }
            .setNegativeButton("No", null)
            .show()
    }

    companion object {
        fun newInstance(param1: String, param2: String) =
            FragmentFirst().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}
