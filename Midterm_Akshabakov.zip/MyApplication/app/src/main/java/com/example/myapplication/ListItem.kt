package com.example.myapplication

data class ListItem(val title: String, val subtitle: String)
